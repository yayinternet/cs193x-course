const child = document.createElement('script');
child.textContent += 'jwplayer().off(\'adBlock\');';
document.body.appendChild(child);
