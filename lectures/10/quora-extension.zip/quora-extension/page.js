document.body.classList.remove('signup_wall_prevent_scroll');
const nagScreen = document.querySelector('.vertical_alignment_wrapper');
if (nagScreen) {
  nagScreen.style.display = 'none';
}
