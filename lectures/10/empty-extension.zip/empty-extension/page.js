console.log('Empty Extension test message');
